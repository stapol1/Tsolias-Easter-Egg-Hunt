let canvas = document.getElementById('gameCanvas');
let ctx = canvas.getContext('2d');

let tsolias = { x: 50, y: 550, width: 40, height: 40, dx: 0, dy: 0, onGround: false };
let gravity = 0.5;
let jumpPower = -10;
let leftPressed = false, rightPressed = false, jumpPressed = false;

let eggs = [];
for (let i = 0; i < 20; i++) {
  eggs.push({ x: Math.random() * 760, y: Math.random() * 500, collected: false });
}

let acropolis = { x: 700, y: 500, width: 80, height: 80 };

let collectedCount = 0;
let startTime = null;
let currentTime = 0;
let personalRecord = parseFloat(localStorage.getItem('tsoliasPR')) || null;
let timerInterval = null;
let gameEnded = false;

function drawPlayer() {
  ctx.fillStyle = 'blue';
  ctx.fillRect(tsolias.x, tsolias.y, tsolias.width, tsolias.height);
}

function drawEggs() {
  ctx.fillStyle = 'red';
  for (let egg of eggs) {
    if (!egg.collected) {
      ctx.beginPath();
      ctx.arc(egg.x, egg.y, 10, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

function drawAcropolis() {
  ctx.fillStyle = 'white';
  ctx.fillRect(acropolis.x, acropolis.y, acropolis.width, acropolis.height);
}

function drawHUD() {
  ctx.fillStyle = 'black';
  ctx.font = '20px Arial';
  ctx.fillText(`Eggs: ${collectedCount}/20`, 10, 20);
  ctx.fillText(`Time: ${currentTime.toFixed(2)}s`, 10, 45);
  if (personalRecord !== null) {
    ctx.fillText(`PR: ${personalRecord.toFixed(2)}s`, 10, 70);
  }
}

function updateTimer() {
  if (startTime && !gameEnded) {
    currentTime = (Date.now() - startTime) / 1000;
  }
}

function update() {
  if (!startTime) startTime = Date.now();
  updateTimer();

  tsolias.dy += gravity;

  if (leftPressed) tsolias.dx = -5;
  else if (rightPressed) tsolias.dx = 5;
  else tsolias.dx = 0;

  if (jumpPressed && tsolias.onGround) {
    tsolias.dy = jumpPower;
    tsolias.onGround = false;
  }

  tsolias.x += tsolias.dx;
  tsolias.y += tsolias.dy;

  if (tsolias.y + tsolias.height >= canvas.height) {
    tsolias.y = canvas.height - tsolias.height;
    tsolias.dy = 0;
    tsolias.onGround = true;
  }

  // Collision with eggs
  for (let egg of eggs) {
    if (!egg.collected &&
        tsolias.x < egg.x + 10 && tsolias.x + tsolias.width > egg.x - 10 &&
        tsolias.y < egg.y + 10 && tsolias.y + tsolias.height > egg.y - 10) {
      egg.collected = true;
      collectedCount++;
    }
  }

  // Win condition
  if (collectedCount === 20 &&
      tsolias.x < acropolis.x + acropolis.width &&
      tsolias.x + tsolias.width > acropolis.x &&
      tsolias.y < acropolis.y + acropolis.height &&
      tsolias.y + tsolias.height > acropolis.y) {
    gameEnded = true;
    clearInterval(timerInterval);
    if (personalRecord === null || currentTime < personalRecord) {
      personalRecord = currentTime;
      localStorage.setItem('tsoliasPR', personalRecord.toString());
    }
    alert(`Victory! Time: ${currentTime.toFixed(2)}s`);
  }
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawPlayer();
  drawEggs();
  drawAcropolis();
  drawHUD();
}

function gameLoop() {
  update();
  draw();
  if (!gameEnded) requestAnimationFrame(gameLoop);
}

document.addEventListener('keydown', e => {
  if (e.key === 'ArrowLeft') leftPressed = true;
  if (e.key === 'ArrowRight') rightPressed = true;
  if (e.key === ' ' || e.key === 'ArrowUp') jumpPressed = true;
});

document.addEventListener('keyup', e => {
  if (e.key === 'ArrowLeft') leftPressed = false;
  if (e.key === 'ArrowRight') rightPressed = false;
  if (e.key === ' ' || e.key === 'ArrowUp') jumpPressed = false;
});

document.getElementById('left').ontouchstart = () => leftPressed = true;
document.getElementById('left').ontouchend = () => leftPressed = false;
document.getElementById('right').ontouchstart = () => rightPressed = true;
document.getElementById('right').ontouchend = () => rightPressed = false;
document.getElementById('jump').ontouchstart = () => jumpPressed = true;
document.getElementById('jump').ontouchend = () => jumpPressed = false;

timerInterval = setInterval(updateTimer, 10);
requestAnimationFrame(gameLoop);